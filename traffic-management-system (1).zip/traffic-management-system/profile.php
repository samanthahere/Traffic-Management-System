<?php
/**
 * Traffic Management System - Profile Management
 * View and edit user profile information based on role
 */

// Include configuration file
require_once 'config.php';

// Require user to be logged in
requireLogin();

// Get user information
$userId = getSessionData('user_id');
$role = getSessionData('role');

$errors = [];
$success = false;
$userProfile = [];

// Handle form submission for profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $firstName = sanitizeInput($_POST['first_name']);
    $lastName = sanitizeInput($_POST['last_name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);
    $dateOfBirth = sanitizeInput($_POST['date_of_birth']);
    
    // Driver-specific fields
    $licenseExpiry = isset($_POST['license_expiry']) ? sanitizeInput($_POST['license_expiry']) : null;
    $experienceYears = isset($_POST['experience_years']) ? (int)$_POST['experience_years'] : null;
    
    // Validation
    if (empty($firstName)) $errors[] = 'First name is required.';
    if (empty($lastName)) $errors[] = 'Last name is required.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    
    // Driver-specific validation
    if ($role === 'driver') {
        if (!empty($licenseExpiry) && strtotime($licenseExpiry) <= time()) {
            $errors[] = 'License expiry date must be in the future.';
        }
        if ($experienceYears !== null && $experienceYears < 0) {
            $errors[] = 'Experience years cannot be negative.';
        }
    }
    
    // Check if email already exists for other users
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM person WHERE email = ? AND id != ?");
            $stmt->execute([$email, $userId]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Email already exists for another user.';
            }
        } catch (PDOException $e) {
            $errors[] = 'Database error. Please try again later.';
            error_log("Profile validation error: " . $e->getMessage());
        }
    }
    
    // If no errors, update the profile
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            $pdo->beginTransaction();
            
            // Update person table
            $stmt = $pdo->prepare("
                UPDATE person 
                SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, date_of_birth = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$firstName, $lastName, $email, $phone, $address, $dateOfBirth, $userId]);
            
            // Update driver table if user is a driver
            if ($role === 'driver' && ($licenseExpiry || $experienceYears !== null)) {
                $updateFields = [];
                $updateValues = [];
                
                if ($licenseExpiry) {
                    $updateFields[] = 'license_expiry = ?';
                    $updateValues[] = $licenseExpiry;
                }
                if ($experienceYears !== null) {
                    $updateFields[] = 'experience_years = ?';
                    $updateValues[] = $experienceYears;
                }
                
                if (!empty($updateFields)) {
                    $updateValues[] = $userId;
                    $stmt = $pdo->prepare("
                        UPDATE driver SET " . implode(', ', $updateFields) . " WHERE driver_id = ?
                    ");
                    $stmt->execute($updateValues);
                }
            }
            
            $pdo->commit();
            $success = true;
            
            // Update session data
            $_SESSION['first_name'] = $firstName;
            $_SESSION['last_name'] = $lastName;
            $_SESSION['email'] = $email;
            
            logActivity('update_profile', 'Profile updated successfully');
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = 'Profile update failed. Please try again.';
            error_log("Profile update error: " . $e->getMessage());
        }
    }
}

// Get current profile data
try {
    $pdo = getDBConnection();
    
    if ($role === 'driver') {
        // Get driver profile with driver-specific information
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.role, u.last_login, 
                   d.ssn, d.license_number, d.license_expiry, d.license_class, d.experience_years, d.status as driver_status
            FROM person p 
            JOIN user u ON p.id = u.user_id 
            JOIN driver d ON p.id = d.driver_id 
            WHERE p.id = ?
        ");
    } elseif ($role === 'admin') {
        // Get admin profile with admin-specific information
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.role, u.last_login, 
                   a.employee_id, a.department, a.position, a.hire_date
            FROM person p 
            JOIN user u ON p.id = u.user_id 
            JOIN admin a ON p.id = a.admin_id 
            WHERE p.id = ?
        ");
    } else {
        // Get regular user profile
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.role, u.last_login
            FROM person p 
            JOIN user u ON p.id = u.user_id 
            WHERE p.id = ?
        ");
    }
    
    $stmt->execute([$userId]);
    $userProfile = $stmt->fetch();
    
} catch (PDOException $e) {
    error_log("Profile fetch error: " . $e->getMessage());
    $userProfile = [];
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    $passwordErrors = [];
    
    // Validation
    if (empty($currentPassword)) $passwordErrors[] = 'Current password is required.';
    if (empty($newPassword) || strlen($newPassword) < 6) $passwordErrors[] = 'New password must be at least 6 characters long.';
    if ($newPassword !== $confirmPassword) $passwordErrors[] = 'New passwords do not match.';
    
    if (empty($passwordErrors)) {
        try {
            $pdo = getDBConnection();
            
            // Verify current password
            $stmt = $pdo->prepare("SELECT password_hash FROM user WHERE user_id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($currentPassword, $user['password_hash'])) {
                // Update password
                $newPasswordHash = password_hash($newPassword, PASSWORD_HASH_ALGO);
                $stmt = $pdo->prepare("UPDATE user SET password_hash = ? WHERE user_id = ?");
                $stmt->execute([$newPasswordHash, $userId]);
                
                logActivity('change_password', 'Password changed successfully');
                $success = 'password_changed';
            } else {
                $passwordErrors[] = 'Current password is incorrect.';
            }
        } catch (PDOException $e) {
            $passwordErrors[] = 'Password change failed. Please try again.';
            error_log("Password change error: " . $e->getMessage());
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg main-header">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-traffic-light me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <div class="navbar-nav ms-auto">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container py-4">
        <div class="row">
            <!-- Profile Information -->
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user me-2"></i>Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($success === true): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>Profile updated successfully!
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($userProfile)): ?>
                            <form method="POST" action="">
                                <!-- Basic Information -->
                                <h6 class="mb-3"><i class="fas fa-info-circle me-2"></i>Basic Information</h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="first_name" class="form-label">First Name *</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" 
                                               value="<?php echo htmlspecialchars($userProfile['first_name']); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="last_name" class="form-label">Last Name *</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" 
                                               value="<?php echo htmlspecialchars($userProfile['last_name']); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo htmlspecialchars($userProfile['email']); ?>" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?php echo htmlspecialchars($userProfile['phone'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="date_of_birth" class="form-label">Date of Birth</label>
                                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 
                                               value="<?php echo $userProfile['date_of_birth']; ?>">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <textarea class="form-control" id="address" name="address" rows="2"><?php echo htmlspecialchars($userProfile['address'] ?? ''); ?></textarea>
                                </div>
                                
                                <!-- Driver-specific fields -->
                                <?php if ($role === 'driver'): ?>
                                    <h6 class="mb-3 mt-4"><i class="fas fa-id-card me-2"></i>Driver Information</h6>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">SSN</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['ssn']); ?>" readonly>
                                            <div class="form-text">Contact admin to change SSN</div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">License Number</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['license_number']); ?>" readonly>
                                            <div class="form-text">Contact admin to change license number</div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="license_expiry" class="form-label">License Expiry</label>
                                            <input type="date" class="form-control" id="license_expiry" name="license_expiry" 
                                                   value="<?php echo $userProfile['license_expiry']; ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">License Class</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['license_class']); ?>" readonly>
                                            <div class="form-text">Contact admin to change license class</div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="experience_years" class="form-label">Experience (Years)</label>
                                            <input type="number" class="form-control" id="experience_years" name="experience_years" 
                                                   value="<?php echo $userProfile['experience_years']; ?>" min="0" max="50">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Driver Status</label>
                                            <div>
                                                <span class="status-badge status-<?php echo $userProfile['driver_status']; ?>">
                                                    <?php echo ucfirst($userProfile['driver_status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Admin-specific fields -->
                                <?php if ($role === 'admin'): ?>
                                    <h6 class="mb-3 mt-4"><i class="fas fa-user-shield me-2"></i>Admin Information</h6>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Employee ID</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['employee_id']); ?>" readonly>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Department</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['department']); ?>" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Position</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userProfile['position']); ?>" readonly>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Hire Date</label>
                                            <input type="date" class="form-control" value="<?php echo $userProfile['hire_date']; ?>" readonly>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Update Profile
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>Unable to load profile information.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Account Information and Actions -->
            <div class="col-lg-4">
                <!-- Account Summary -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Account Summary</h6>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($userProfile)): ?>
                            <p><strong>Username:</strong> <?php echo htmlspecialchars($userProfile['username']); ?></p>
                            <p><strong>Role:</strong> 
                                <span class="badge bg-primary"><?php echo ucfirst($userProfile['role']); ?></span>
                            </p>
                            <p><strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($userProfile['created_at'])); ?></p>
                            <p><strong>Last Login:</strong> 
                                <?php 
                                if ($userProfile['last_login']) {
                                    echo date('F j, Y g:i A', strtotime($userProfile['last_login']));
                                } else {
                                    echo 'Never';
                                }
                                ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Change Password -->
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-key me-2"></i>Change Password</h6>
                    </div>
                    <div class="card-body">
                        <?php if ($success === 'password_changed'): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>Password changed successfully!
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($passwordErrors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($passwordErrors as $error): ?>
                                        <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                                <div class="form-text">Minimum 6 characters</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
                            </div>
                            
                            <button type="submit" name="change_password" class="btn btn-warning w-100">
                                <i class="fas fa-key me-2"></i>Change Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Password confirmation validation
    document.addEventListener('DOMContentLoaded', function() {
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        
        function validatePassword() {
            if (newPassword.value !== confirmPassword.value) {
                confirmPassword.setCustomValidity('Passwords do not match');
            } else {
                confirmPassword.setCustomValidity('');
            }
        }
        
        newPassword.addEventListener('input', validatePassword);
        confirmPassword.addEventListener('input', validatePassword);
    });
    </script>
</body>
</html>