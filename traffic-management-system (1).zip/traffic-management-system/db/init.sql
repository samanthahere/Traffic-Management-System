-- Traffic Management System Database Schema
-- Created for beginner-friendly implementation

-- Create database
CREATE DATABASE IF NOT EXISTS traffic_management;
USE traffic_management;

-- Drop existing tables (for fresh setup)
DROP TABLE IF EXISTS fine;
DROP TABLE IF EXISTS incident;
DROP TABLE IF EXISTS location;
DROP TABLE IF EXISTS police_car;
DROP TABLE IF EXISTS ambulance;
DROP TABLE IF EXISTS vehicle;
DROP TABLE IF EXISTS admin;
DROP TABLE IF EXISTS driver;
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS person;

-- Create person table (base table for all users)
CREATE TABLE person (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    date_of_birth DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create user table (extends person for regular users)
CREATE TABLE user (
    user_id INT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'driver', 'admin') NOT NULL DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES person(id) ON DELETE CASCADE
);

-- Create driver table (extends person for drivers)
CREATE TABLE driver (
    driver_id INT PRIMARY KEY,
    ssn VARCHAR(20) UNIQUE NOT NULL,
    license_number VARCHAR(50) UNIQUE NOT NULL,
    license_expiry DATE NOT NULL,
    license_class VARCHAR(10) NOT NULL,
    experience_years INT DEFAULT 0,
    status ENUM('active', 'suspended', 'revoked') DEFAULT 'active',
    FOREIGN KEY (driver_id) REFERENCES person(id) ON DELETE CASCADE
);

-- Create admin table (extends person for administrators)
CREATE TABLE admin (
    admin_id INT PRIMARY KEY,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    department VARCHAR(50) NOT NULL,
    position VARCHAR(50) NOT NULL,
    hire_date DATE NOT NULL,
    permissions TEXT, -- JSON string for detailed permissions
    FOREIGN KEY (admin_id) REFERENCES person(id) ON DELETE CASCADE
);

-- Create vehicle table
CREATE TABLE vehicle (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    license_plate VARCHAR(20) UNIQUE NOT NULL,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    color VARCHAR(30) NOT NULL,
    vin VARCHAR(17) UNIQUE NOT NULL,
    registration_expiry DATE NOT NULL,
    insurance_expiry DATE NOT NULL,
    status ENUM('active', 'inactive', 'impounded') DEFAULT 'active',
    assigned_driver_ssn VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_driver_ssn) REFERENCES driver(ssn) ON DELETE SET NULL
);

-- Create location table for tracking
CREATE TABLE location (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    start_latitude DECIMAL(10, 8),
    start_longitude DECIMAL(11, 8),
    end_latitude DECIMAL(10, 8),
    end_longitude DECIMAL(11, 8),
    start_address TEXT,
    end_address TEXT,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NULL,
    distance_km DECIMAL(8, 2),
    purpose VARCHAR(100),
    vehicle_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES person(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id) ON DELETE SET NULL
);

-- Create incident table
CREATE TABLE incident (
    incident_id INT AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT NOT NULL,
    incident_type ENUM('accident', 'traffic_violation', 'emergency', 'other') NOT NULL,
    description TEXT NOT NULL,
    incident_date TIMESTAMP NOT NULL,
    location_address TEXT NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    vehicles_involved TEXT, -- JSON string for multiple vehicles
    drivers_involved TEXT,  -- JSON string for multiple drivers
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    status ENUM('reported', 'investigating', 'resolved', 'closed') DEFAULT 'reported',
    assigned_admin_id INT,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (reporter_id) REFERENCES person(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_admin_id) REFERENCES admin(admin_id) ON DELETE SET NULL
);

-- Create fine table
CREATE TABLE fine (
    fine_id INT AUTO_INCREMENT PRIMARY KEY,
    driver_ssn VARCHAR(20) NOT NULL,
    issued_by_admin_id INT NOT NULL,
    incident_id INT,
    violation_type VARCHAR(100) NOT NULL,
    fine_amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    issue_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    due_date DATE NOT NULL,
    status ENUM('pending', 'paid', 'overdue', 'cancelled') DEFAULT 'pending',
    payment_date TIMESTAMP NULL,
    payment_method VARCHAR(50),
    location_address TEXT,
    FOREIGN KEY (driver_ssn) REFERENCES driver(ssn) ON DELETE CASCADE,
    FOREIGN KEY (issued_by_admin_id) REFERENCES admin(admin_id) ON DELETE CASCADE,
    FOREIGN KEY (incident_id) REFERENCES incident(incident_id) ON DELETE SET NULL
);

-- Create ambulance table (special vehicle type)
CREATE TABLE ambulance (
    ambulance_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    hospital_name VARCHAR(100) NOT NULL,
    equipment_list TEXT,
    medical_license VARCHAR(50) NOT NULL,
    capacity INT DEFAULT 2,
    emergency_contact VARCHAR(15),
    status ENUM('available', 'on_call', 'maintenance') DEFAULT 'available',
    FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id) ON DELETE CASCADE
);

-- Create police_car table (special vehicle type)
CREATE TABLE police_car (
    police_car_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    badge_number VARCHAR(20) NOT NULL,
    department VARCHAR(50) NOT NULL,
    unit_number VARCHAR(20) NOT NULL,
    equipment_list TEXT,
    jurisdiction VARCHAR(100),
    status ENUM('patrol', 'responding', 'off_duty', 'maintenance') DEFAULT 'patrol',
    FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id) ON DELETE CASCADE
);

-- Insert sample data for testing

-- Sample persons
INSERT INTO person (first_name, last_name, email, phone, address, date_of_birth) VALUES
('John', 'Doe', 'john.doe@email.com', '123-456-7890', '123 Main St, City, State 12345', '1985-06-15'),
('Jane', 'Smith', 'jane.smith@email.com', '098-765-4321', '456 Oak Ave, City, State 12345', '1990-03-22'),
('Mike', 'Johnson', 'mike.johnson@email.com', '555-123-4567', '789 Pine St, City, State 12345', '1982-11-08'),
('Sarah', 'Wilson', 'sarah.wilson@email.com', '444-555-6666', '321 Elm St, City, State 12345', '1988-09-14'),
('Admin', 'User', 'admin@traffic.gov', '999-888-7777', '100 Government Blvd, City, State 12345', '1975-01-01');

-- Sample users (password is 'password123' hashed)
INSERT INTO user (user_id, username, password_hash, role) VALUES
(1, 'johndoe', '$2y$10$5e3kShwj.V6JDXy.7ANivuhwro34XeToJBTkL0U0nk.KoogQWBbxS', 'user'),
(2, 'janesmith', '$2y$10$5e3kShwj.V6JDXy.7ANivuhwro34XeToJBTkL0U0nk.KoogQWBbxS', 'driver'),
(3, 'mikejohnson', '$2y$10$5e3kShwj.V6JDXy.7ANivuhwro34XeToJBTkL0U0nk.KoogQWBbxS', 'driver'),
(4, 'sarahwilson', '$2y$10$5e3kShwj.V6JDXy.7ANivuhwro34XeToJBTkL0U0nk.KoogQWBbxS', 'user'),
(5, 'admin', '$2y$10$5e3kShwj.V6JDXy.7ANivuhwro34XeToJBTkL0U0nk.KoogQWBbxS', 'admin');

-- Sample drivers
INSERT INTO driver (driver_id, ssn, license_number, license_expiry, license_class, experience_years) VALUES
(2, '123-45-6789', 'DL123456789', '2025-12-31', 'Class C', 8),
(3, '987-65-4321', 'DL987654321', '2026-06-30', 'Class B', 15);

-- Sample admin
INSERT INTO admin (admin_id, employee_id, department, position, hire_date, permissions) VALUES
(5, 'EMP001', 'Traffic Management', 'System Administrator', '2020-01-15', '{"manage_users": true, "issue_fines": true, "view_incidents": true}');

-- Sample vehicles
INSERT INTO vehicle (license_plate, make, model, year, color, vin, registration_expiry, insurance_expiry, assigned_driver_ssn) VALUES
('ABC-123', 'Toyota', 'Camry', 2020, 'Blue', '1HGBH41JXMN109186', '2025-08-31', '2025-06-30', '123-45-6789'),
('XYZ-789', 'Ford', 'F-150', 2019, 'Red', '1FTFW1ET5DKE10312', '2025-10-15', '2025-09-20', '987-65-4321'),
('EMG-001', 'Mercedes', 'Sprinter', 2021, 'White', '1FDEE3FL6DDA12345', '2025-12-01', '2025-11-15', NULL),
('POL-001', 'Chevrolet', 'Tahoe', 2022, 'Black', '1GNSKBKC1NR123456', '2026-01-31', '2025-12-31', NULL);

-- Sample ambulance
INSERT INTO ambulance (vehicle_id, hospital_name, equipment_list, medical_license, capacity, emergency_contact) VALUES
(3, 'City General Hospital', 'Defibrillator, Oxygen Tank, Stretcher, First Aid Kit', 'MED123456', 2, '911');

-- Sample police car
INSERT INTO police_car (vehicle_id, badge_number, department, unit_number, equipment_list, jurisdiction) VALUES
(4, 'BADGE001', 'City Police Department', 'UNIT-01', 'Radio, Computer, Camera, First Aid', 'City Limits');

COMMIT;