<?php
/**
 * Traffic Management System - Login Page
 * Main entry point for user authentication
 */

// Include configuration file
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $loginError = '';
    
    // Validate input
    if (empty($username) || empty($password)) {
        $loginError = 'Please enter both username and password.';
    } else {
        try {
            $pdo = getDBConnection();
            
            // Get user information with person details
            $stmt = $pdo->prepare("
                SELECT u.user_id, u.username, u.password_hash, u.role, u.is_active,
                       p.first_name, p.last_name, p.email
                FROM user u 
                JOIN person p ON u.user_id = p.id 
                WHERE u.username = ? AND u.is_active = 1
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                // Successful login - create session
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['last_activity'] = time();
                
                // Update last login time
                $updateStmt = $pdo->prepare("UPDATE user SET last_login = NOW() WHERE user_id = ?");
                $updateStmt->execute([$user['user_id']]);
                
                // Log successful login
                logActivity('login', 'User logged in successfully');
                
                // Redirect to dashboard
                header('Location: dashboard.php');
                exit();
            } else {
                $loginError = 'Invalid username or password.';
                logActivity('failed_login', "Failed login attempt for username: $username");
            }
        } catch (PDOException $e) {
            $loginError = 'Database error. Please try again later.';
            error_log("Login error: " . $e->getMessage());
        }
    }
}

// Get any error messages from URL parameters
$urlError = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'login_required':
            $urlError = 'Please log in to access this page.';
            break;
        case 'session_expired':
            $urlError = 'Your session has expired. Please log in again.';
            break;
        case 'access_denied':
            $urlError = 'Access denied. You do not have permission to access that page.';
            break;
        default:
            $urlError = 'An error occurred. Please try logging in again.';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <!-- Login Header -->
            <div class="login-header">
                <i class="fas fa-traffic-light fa-3x mb-3"></i>
                <h2><?php echo SITE_NAME; ?></h2>
                <p class="mb-0">Secure Access Portal</p>
            </div>
            
            <!-- Login Form -->
            <div class="login-body">
                <?php if (!empty($loginError)): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo htmlspecialchars($loginError); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($urlError)): ?>
                    <div class="alert alert-warning" role="alert">
                        <i class="fas fa-info-circle me-2"></i>
                        <?php echo htmlspecialchars($urlError); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['registered'])): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        Registration successful! Please log in with your credentials.
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['logged_out'])): ?>
                    <div class="alert alert-info" role="alert">
                        <i class="fas fa-sign-out-alt me-2"></i>
                        You have been logged out successfully.
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="loginForm">
                    <div class="mb-3">
                        <label for="username" class="form-label">
                            <i class="fas fa-user me-2"></i>Username
                        </label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>"
                               required autocomplete="username">
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="form-label">
                            <i class="fas fa-lock me-2"></i>Password
                        </label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" 
                                   required autocomplete="current-password">
                            <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" name="login" class="btn btn-primary w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </button>
                </form>
                
                <div class="text-center">
                    <p class="mb-2">Don't have an account?</p>
                    <a href="register.php" class="btn btn-outline-primary">
                        <i class="fas fa-user-plus me-2"></i>Register Here
                    </a>
                </div>
                
                <!-- Demo Accounts Info -->
                <div class="mt-4 pt-3 border-top">
                    <h6 class="text-center mb-3">Demo Accounts:</h6>
                    <div class="row g-2 text-sm">
                        <div class="col-4">
                            <div class="p-2 bg-light rounded text-center">
                                <strong>Admin</strong><br>
                                <small>admin / password123</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-light rounded text-center">
                                <strong>Driver</strong><br>
                                <small>janesmith / password123</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-light rounded text-center">
                                <strong>User</strong><br>
                                <small>johndoe / password123</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center mt-4">
            <p class="text-white-50">
                <small>&copy; <?php echo date('Y'); ?> Traffic Management System. All rights reserved.</small>
            </p>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordField = document.getElementById('password');
        const toggleIcon = this.querySelector('i');
        
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    });
    
    // Form validation
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        
        if (!username || !password) {
            e.preventDefault();
            alert('Please enter both username and password.');
        }
    });
    
    // Auto-focus on username field
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('username').focus();
    });
    </script>
</body>
</html>