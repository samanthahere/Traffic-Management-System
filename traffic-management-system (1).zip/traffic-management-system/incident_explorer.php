<?php
/**
 * Traffic Management System - Incident Explorer
 * Admin can view all incidents, Users can view their own incidents
 */

// Include configuration file
require_once 'config.php';

// Require user to be logged in
requireLogin();

// Get user information
$userId = getSessionData('user_id');
$role = getSessionData('role');

// Handle admin actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $role === 'admin') {
    if (isset($_POST['update_status'])) {
        $incidentId = (int)$_POST['incident_id'];
        $newStatus = sanitizeInput($_POST['status']);
        $resolutionNotes = sanitizeInput($_POST['resolution_notes']);
        
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("
                UPDATE incident 
                SET status = ?, resolution_notes = ?, assigned_admin_id = ?, 
                    resolved_at = CASE WHEN ? IN ('resolved', 'closed') THEN NOW() ELSE resolved_at END
                WHERE incident_id = ?
            ");
            $stmt->execute([$newStatus, $resolutionNotes, $userId, $newStatus, $incidentId]);
            
            logActivity('update_incident_status', "Updated incident $incidentId status to $newStatus");
            header('Location: incident_explorer.php?msg=updated');
            exit();
        } catch (PDOException $e) {
            error_log("Update incident error: " . $e->getMessage());
        }
    }
}

// Get incidents based on role
$incidents = [];
$filters = [
    'status' => $_GET['status'] ?? '',
    'type' => $_GET['type'] ?? '',
    'severity' => $_GET['severity'] ?? '',
    'search' => $_GET['search'] ?? ''
];

try {
    $pdo = getDBConnection();
    
    // Build query based on role
    if ($role === 'admin') {
        // Admin can see all incidents
        $whereClause = "WHERE 1=1";
        $params = [];
    } else {
        // Users can only see their own incidents
        $whereClause = "WHERE i.reporter_id = ?";
        $params = [$userId];
    }
    
    // Add filters
    if (!empty($filters['status'])) {
        $whereClause .= " AND i.status = ?";
        $params[] = $filters['status'];
    }
    
    if (!empty($filters['type'])) {
        $whereClause .= " AND i.incident_type = ?";
        $params[] = $filters['type'];
    }
    
    if (!empty($filters['severity'])) {
        $whereClause .= " AND i.severity = ?";
        $params[] = $filters['severity'];
    }
    
    if (!empty($filters['search'])) {
        $whereClause .= " AND (i.description LIKE ? OR i.location_address LIKE ?)";
        $searchTerm = '%' . $filters['search'] . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    $query = "
        SELECT i.*, p.first_name, p.last_name, p.email,
               admin_p.first_name as admin_first_name, admin_p.last_name as admin_last_name
        FROM incident i 
        JOIN person p ON i.reporter_id = p.id 
        LEFT JOIN admin a ON i.assigned_admin_id = a.admin_id
        LEFT JOIN person admin_p ON a.admin_id = admin_p.id
        $whereClause 
        ORDER BY i.created_at DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $incidents = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Incident fetch error: " . $e->getMessage());
    $incidents = [];
}

// Get specific incident details if ID is provided
$incidentDetails = null;
if (isset($_GET['id'])) {
    $incidentId = (int)$_GET['id'];
    try {
        $whereClause = $role === 'admin' ? "WHERE i.incident_id = ?" : "WHERE i.incident_id = ? AND i.reporter_id = ?";
        $params = $role === 'admin' ? [$incidentId] : [$incidentId, $userId];
        
        $stmt = $pdo->prepare("
            SELECT i.*, p.first_name, p.last_name, p.email, p.phone,
                   admin_p.first_name as admin_first_name, admin_p.last_name as admin_last_name
            FROM incident i 
            JOIN person p ON i.reporter_id = p.id 
            LEFT JOIN admin a ON i.assigned_admin_id = a.admin_id
            LEFT JOIN person admin_p ON a.admin_id = admin_p.id
            $whereClause
        ");
        $stmt->execute($params);
        $incidentDetails = $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Incident details error: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $role === 'admin' ? 'Incident Explorer' : 'My Incidents'; ?> - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg main-header">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-traffic-light me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <div class="navbar-nav ms-auto">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid py-4">
        <!-- Messages -->
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'updated'): ?>
            <?php displayMessage('success', 'Incident status updated successfully.'); ?>
        <?php endif; ?>
        
        <?php if ($incidentDetails): ?>
            <!-- Incident Details Modal/View -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Incident #<?php echo $incidentDetails['incident_id']; ?>
                            </h5>
                            <a href="incident_explorer.php" class="btn btn-outline-secondary btn-sm">
                                <i class="fas fa-times me-2"></i>Close Details
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <h6><i class="fas fa-info-circle me-2"></i>Incident Information</h6>
                                    <table class="table table-borderless">
                                        <tr>
                                            <td><strong>Type:</strong></td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo ucfirst(str_replace('_', ' ', $incidentDetails['incident_type'])); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Severity:</strong></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $incidentDetails['severity']; ?>">
                                                    <?php echo ucfirst($incidentDetails['severity']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Status:</strong></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $incidentDetails['status']; ?>">
                                                    <?php echo ucfirst($incidentDetails['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Date/Time:</strong></td>
                                            <td><?php echo date('F j, Y g:i A', strtotime($incidentDetails['incident_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Location:</strong></td>
                                            <td><?php echo htmlspecialchars($incidentDetails['location_address']); ?></td>
                                        </tr>
                                        <?php if ($incidentDetails['latitude'] && $incidentDetails['longitude']): ?>
                                        <tr>
                                            <td><strong>Coordinates:</strong></td>
                                            <td><?php echo $incidentDetails['latitude']; ?>, <?php echo $incidentDetails['longitude']; ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    </table>
                                    
                                    <h6 class="mt-3"><i class="fas fa-file-alt me-2"></i>Description</h6>
                                    <p class="border p-3 bg-light rounded"><?php echo nl2br(htmlspecialchars($incidentDetails['description'])); ?></p>
                                    
                                    <?php if ($incidentDetails['vehicles_involved']): ?>
                                        <h6><i class="fas fa-car me-2"></i>Vehicles Involved</h6>
                                        <p><?php echo htmlspecialchars(implode(', ', json_decode($incidentDetails['vehicles_involved'], true))); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if ($incidentDetails['drivers_involved']): ?>
                                        <h6><i class="fas fa-users me-2"></i>People Involved</h6>
                                        <p><?php echo htmlspecialchars(implode(', ', json_decode($incidentDetails['drivers_involved'], true))); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if ($incidentDetails['resolution_notes']): ?>
                                        <h6><i class="fas fa-clipboard-check me-2"></i>Resolution Notes</h6>
                                        <p class="border p-3 bg-light rounded"><?php echo nl2br(htmlspecialchars($incidentDetails['resolution_notes'])); ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-4">
                                    <h6><i class="fas fa-user me-2"></i>Reporter Information</h6>
                                    <table class="table table-borderless table-sm">
                                        <tr>
                                            <td><strong>Name:</strong></td>
                                            <td><?php echo htmlspecialchars($incidentDetails['first_name'] . ' ' . $incidentDetails['last_name']); ?></td>
                                        </tr>
                                        <?php if ($role === 'admin'): ?>
                                        <tr>
                                            <td><strong>Email:</strong></td>
                                            <td><a href="mailto:<?php echo $incidentDetails['email']; ?>"><?php echo htmlspecialchars($incidentDetails['email']); ?></a></td>
                                        </tr>
                                        <?php if ($incidentDetails['phone']): ?>
                                        <tr>
                                            <td><strong>Phone:</strong></td>
                                            <td><a href="tel:<?php echo $incidentDetails['phone']; ?>"><?php echo htmlspecialchars($incidentDetails['phone']); ?></a></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <tr>
                                            <td><strong>Reported:</strong></td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($incidentDetails['created_at'])); ?></td>
                                        </tr>
                                    </table>
                                    
                                    <?php if ($incidentDetails['admin_first_name']): ?>
                                        <h6 class="mt-3"><i class="fas fa-user-shield me-2"></i>Assigned Admin</h6>
                                        <p><?php echo htmlspecialchars($incidentDetails['admin_first_name'] . ' ' . $incidentDetails['admin_last_name']); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if ($role === 'admin'): ?>
                                        <!-- Admin Actions -->
                                        <div class="mt-4">
                                            <h6><i class="fas fa-cogs me-2"></i>Admin Actions</h6>
                                            <form method="POST" action="">
                                                <input type="hidden" name="incident_id" value="<?php echo $incidentDetails['incident_id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="status" class="form-label">Status</label>
                                                    <select class="form-select" name="status" required>
                                                        <option value="reported" <?php echo $incidentDetails['status'] === 'reported' ? 'selected' : ''; ?>>Reported</option>
                                                        <option value="investigating" <?php echo $incidentDetails['status'] === 'investigating' ? 'selected' : ''; ?>>Investigating</option>
                                                        <option value="resolved" <?php echo $incidentDetails['status'] === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                                                        <option value="closed" <?php echo $incidentDetails['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="resolution_notes" class="form-label">Resolution Notes</label>
                                                    <textarea class="form-control" name="resolution_notes" rows="3" 
                                                              placeholder="Add notes about the resolution..."><?php echo htmlspecialchars($incidentDetails['resolution_notes'] ?? ''); ?></textarea>
                                                </div>
                                                
                                                <button type="submit" name="update_status" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-save me-2"></i>Update Status
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Incidents List -->
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>
                            <?php echo $role === 'admin' ? 'All Incidents' : 'My Incidents'; ?>
                        </h5>
                    </div>
                    <div class="col-md-6 text-end">
                        <?php if ($role !== 'admin'): ?>
                            <a href="report_incident.php" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus me-2"></i>Report New Incident
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Filters -->
                <form method="GET" action="" class="row g-3 mb-4">
                    <div class="col-md-3">
                        <select class="form-select" name="status">
                            <option value="">All Statuses</option>
                            <option value="reported" <?php echo $filters['status'] === 'reported' ? 'selected' : ''; ?>>Reported</option>
                            <option value="investigating" <?php echo $filters['status'] === 'investigating' ? 'selected' : ''; ?>>Investigating</option>
                            <option value="resolved" <?php echo $filters['status'] === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                            <option value="closed" <?php echo $filters['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="type">
                            <option value="">All Types</option>
                            <option value="accident" <?php echo $filters['type'] === 'accident' ? 'selected' : ''; ?>>Traffic Accident</option>
                            <option value="traffic_violation" <?php echo $filters['type'] === 'traffic_violation' ? 'selected' : ''; ?>>Traffic Violation</option>
                            <option value="emergency" <?php echo $filters['type'] === 'emergency' ? 'selected' : ''; ?>>Emergency</option>
                            <option value="other" <?php echo $filters['type'] === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="severity">
                            <option value="">All Severities</option>
                            <option value="low" <?php echo $filters['severity'] === 'low' ? 'selected' : ''; ?>>Low</option>
                            <option value="medium" <?php echo $filters['severity'] === 'medium' ? 'selected' : ''; ?>>Medium</option>
                            <option value="high" <?php echo $filters['severity'] === 'high' ? 'selected' : ''; ?>>High</option>
                            <option value="critical" <?php echo $filters['severity'] === 'critical' ? 'selected' : ''; ?>>Critical</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search..." 
                                   value="<?php echo htmlspecialchars($filters['search']); ?>">
                            <button type="submit" class="btn btn-outline-primary">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
                
                <!-- Incidents Table -->
                <?php if (!empty($incidents)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <?php if ($role === 'admin'): ?>
                                        <th>Reporter</th>
                                    <?php endif; ?>
                                    <th>Type</th>
                                    <th>Severity</th>
                                    <th>Location</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($incidents as $incident): ?>
                                    <tr>
                                        <td>#<?php echo $incident['incident_id']; ?></td>
                                        <?php if ($role === 'admin'): ?>
                                            <td>
                                                <div class="small">
                                                    <?php echo htmlspecialchars($incident['first_name'] . ' ' . $incident['last_name']); ?>
                                                    <br><small class="text-muted"><?php echo htmlspecialchars($incident['email']); ?></small>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo ucfirst(str_replace('_', ' ', $incident['incident_type'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $incident['severity']; ?>">
                                                <?php echo ucfirst($incident['severity']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="small" title="<?php echo htmlspecialchars($incident['location_address']); ?>">
                                                <?php echo htmlspecialchars(substr($incident['location_address'], 0, 30)); ?>
                                                <?php if (strlen($incident['location_address']) > 30) echo '...'; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <?php echo date('M j, Y', strtotime($incident['incident_date'])); ?><br>
                                                <?php echo date('g:i A', strtotime($incident['incident_date'])); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $incident['status']; ?>">
                                                <?php echo ucfirst($incident['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="incident_explorer.php?id=<?php echo $incident['incident_id']; ?>" 
                                               class="btn btn-sm btn-outline-primary" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h5>No incidents found</h5>
                        <p class="text-muted">
                            <?php if ($role === 'admin'): ?>
                                No incidents match your current filters.
                            <?php else: ?>
                                You haven't reported any incidents yet.
                            <?php endif; ?>
                        </p>
                        <?php if ($role !== 'admin'): ?>
                            <a href="report_incident.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Report Your First Incident
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>