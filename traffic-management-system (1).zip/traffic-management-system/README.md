# Traffic Management System

A beginner-friendly Traffic Management System built with HTML, CSS, PHP, and MySQL. This system provides role-based access control for managing traffic incidents, vehicles, drivers, and fines.

## 🌟 Features

### 🔐 User Roles & Authentication
- **Admin**: Full system access - manage vehicles, view all incidents, issue fines
- **Driver**: View personal profile, fines, and report incidents
- **User**: Report incidents and track personal location data

### 📊 Core Modules
1. **Profile Management** - View and edit user information
2. **Vehicle Database** - CRUD operations for vehicles (Admin only)
3. **Location Tracking** - Track start/end points with time and distance
4. **Incident Reporting** - User-friendly incident reporting form
5. **Incident Explorer** - View and manage incidents (role-based)
6. **Fine Ledger** - Issue and manage traffic fines

## 🗄️ Database Schema

The system uses MySQL with the following main tables:
- `person` - Base table for all users
- `user` - User authentication and roles
- `driver` - Driver-specific information
- `admin` - Administrator details
- `vehicle` - Vehicle records and assignments
- `incident` - Traffic incident reports
- `location` - Location tracking data
- `fine` - Traffic violation fines
- `ambulance` & `police_car` - Special vehicle types

## 🚀 Installation

### Prerequisites
- XAMPP, WAMP, or similar local server environment
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser

### Setup Steps

1. **Download/Clone the project**
   ```
   Place the 'traffic-management-system' folder in your web server directory
   (e.g., htdocs for XAMPP)
   ```

2. **Database Setup**
   - Start your MySQL server
   - Create a new database named `traffic_management`
   - Import the database schema:
     ```sql
     source /path/to/traffic-management-system/db/init.sql
     ```
   - Or run the SQL commands from `db/init.sql` in phpMyAdmin

3. **Configuration**
   - Open `config.php`
   - Update database credentials if needed:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'traffic_management');
     define('DB_USER', 'root');      // Your MySQL username
     define('DB_PASS', '');          // Your MySQL password
     ```

4. **Access the System**
   - Navigate to `http://localhost/traffic-management-system/`
   - Use demo accounts or register new users

## 👥 Demo Accounts

The system comes with pre-configured demo accounts:

| Role | Username | Password | Description |
|------|----------|----------|-------------|
| Admin | admin | password123 | Full system access |
| Driver | janesmith | password123 | Driver with assigned vehicle |
| Driver | mikejohnson | password123 | Another driver account |
| User | johndoe | password123 | Regular user account |
| User | sarahwilson | password123 | Another user account |

## 📱 User Guide

### For Admins
1. **Dashboard** - View system statistics and recent incidents
2. **Vehicle Management** - Add, edit, delete vehicles and assign drivers
3. **Incident Explorer** - View all incidents, update status, assign to admins
4. **Fine Ledger** - Issue fines to drivers, manage payment status

### For Drivers
1. **Dashboard** - View assigned vehicle, pending fines, and personal stats
2. **Profile** - Update personal information and license details
3. **My Fines** - View and track fine payments
4. **Report Incident** - Report traffic incidents

### For Users
1. **Dashboard** - Quick actions and incident history
2. **Report Incident** - Report traffic incidents with location data
3. **My Incidents** - View reported incidents and their status
4. **Location Tracking** - Track and log location data

## 🛠️ Technical Features

### Security
- Password hashing using PHP's `password_hash()`
- Session management with timeout
- SQL injection prevention with prepared statements
- CSRF token protection for forms
- Input sanitization and validation

### User Experience
- Responsive Bootstrap 5 design
- Mobile-friendly interface
- Real-time location detection (HTML5 Geolocation)
- Form validation (client and server-side)
- Status badges and visual indicators

### Code Quality
- Well-commented code for beginners
- Consistent coding style
- Error logging and handling
- Modular file structure

## 📁 File Structure

```
traffic-management-system/
├── css/
│   └── style.css              # Custom CSS styles
├── db/
│   └── init.sql              # Database schema and sample data
├── config.php                # Database configuration and helper functions
├── index.php                 # Login page
├── register.php              # User registration
├── dashboard.php             # Role-based dashboard
├── profile.php               # Profile management
├── vehicles.php              # Vehicle management (Admin)
├── location.php              # Location tracking
├── report_incident.php       # Incident reporting form
├── incident_explorer.php     # Incident management
├── fines.php                 # Fine ledger system
└── logout.php                # Logout handler
```

## 🎨 Customization

### Styling
- Modify `css/style.css` for custom themes
- Update Bootstrap variables in the CSS root section
- Change color scheme using CSS custom properties

### Database
- Add new tables by modifying `db/init.sql`
- Extend existing tables with additional columns
- Create new relationships as needed

### Features
- Add new incident types in `report_incident.php`
- Extend violation types in `fines.php`
- Add new user roles in the database and update `config.php`

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check MySQL server is running
   - Verify database credentials in `config.php`
   - Ensure database exists and is properly imported

2. **Session Issues**
   - Check if PHP sessions are enabled
   - Verify session timeout settings
   - Clear browser cache and cookies

3. **Permission Errors**
   - Ensure web server has read/write permissions
   - Check file ownership and permissions

4. **Display Issues**
   - Verify Bootstrap CSS is loading properly
   - Check for JavaScript errors in browser console
   - Ensure internet connection for CDN resources

## 📝 License

This project is created for educational purposes. Feel free to use, modify, and distribute as needed.

## 🤝 Contributing

This is a beginner-friendly project. Contributions are welcome for:
- Bug fixes
- Feature enhancements
- Documentation improvements
- Code optimization

## 📞 Support

For questions or issues:
1. Check the troubleshooting section
2. Review the code comments for understanding
3. Ensure all prerequisites are met
4. Verify database setup is correct

---

**Happy Coding! 🚗💨**