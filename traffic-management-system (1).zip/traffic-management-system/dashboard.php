<?php
/**
 * Traffic Management System - Dashboard
 * Role-based dashboard with different views for Admin, Driver, and User
 */

// Include configuration file
require_once 'config.php';

// Require user to be logged in
requireLogin();

// Get user information
$userId = getSessionData('user_id');
$username = getSessionData('username');
$role = getSessionData('role');
$firstName = getSessionData('first_name');
$lastName = getSessionData('last_name');

// Initialize dashboard data
$dashboardData = [];

try {
    $pdo = getDBConnection();
    
    // Get dashboard statistics based on role
    if ($role === 'admin') {
        // Admin statistics
        $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM user WHERE role != 'admin'");
        $dashboardData['total_users'] = $stmt->fetch()['total_users'];
        
        $stmt = $pdo->query("SELECT COUNT(*) as total_drivers FROM driver");
        $dashboardData['total_drivers'] = $stmt->fetch()['total_drivers'];
        
        $stmt = $pdo->query("SELECT COUNT(*) as total_vehicles FROM vehicle");
        $dashboardData['total_vehicles'] = $stmt->fetch()['total_vehicles'];
        
        $stmt = $pdo->query("SELECT COUNT(*) as pending_incidents FROM incident WHERE status = 'reported'");
        $dashboardData['pending_incidents'] = $stmt->fetch()['pending_incidents'];
        
        $stmt = $pdo->query("SELECT COUNT(*) as pending_fines FROM fine WHERE status = 'pending'");
        $dashboardData['pending_fines'] = $stmt->fetch()['pending_fines'];
        
        // Recent incidents
        $stmt = $pdo->prepare("
            SELECT i.*, p.first_name, p.last_name 
            FROM incident i 
            JOIN person p ON i.reporter_id = p.id 
            ORDER BY i.created_at DESC 
            LIMIT 5
        ");
        $stmt->execute();
        $dashboardData['recent_incidents'] = $stmt->fetchAll();
        
    } elseif ($role === 'driver') {
        // Driver statistics
        $stmt = $pdo->prepare("SELECT COUNT(*) as my_fines FROM fine f JOIN driver d ON f.driver_ssn = d.ssn WHERE d.driver_id = ?");
        $stmt->execute([$userId]);
        $dashboardData['my_fines'] = $stmt->fetch()['my_fines'];
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as pending_fines FROM fine f JOIN driver d ON f.driver_ssn = d.ssn WHERE d.driver_id = ? AND f.status = 'pending'");
        $stmt->execute([$userId]);
        $dashboardData['pending_fines'] = $stmt->fetch()['pending_fines'];
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as my_incidents FROM incident WHERE reporter_id = ?");
        $stmt->execute([$userId]);
        $dashboardData['my_incidents'] = $stmt->fetch()['my_incidents'];
        
        // Get assigned vehicle
        $stmt = $pdo->prepare("
            SELECT v.* FROM vehicle v 
            JOIN driver d ON v.assigned_driver_ssn = d.ssn 
            WHERE d.driver_id = ?
        ");
        $stmt->execute([$userId]);
        $dashboardData['assigned_vehicle'] = $stmt->fetch();
        
        // Recent fines
        $stmt = $pdo->prepare("
            SELECT f.* FROM fine f 
            JOIN driver d ON f.driver_ssn = d.ssn 
            WHERE d.driver_id = ? 
            ORDER BY f.issue_date DESC 
            LIMIT 5
        ");
        $stmt->execute([$userId]);
        $dashboardData['recent_fines'] = $stmt->fetchAll();
        
    } else { // Regular user
        // User statistics
        $stmt = $pdo->prepare("SELECT COUNT(*) as my_incidents FROM incident WHERE reporter_id = ?");
        $stmt->execute([$userId]);
        $dashboardData['my_incidents'] = $stmt->fetch()['my_incidents'];
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as my_locations FROM location WHERE user_id = ?");
        $stmt->execute([$userId]);
        $dashboardData['my_locations'] = $stmt->fetch()['my_locations'];
        
        // Recent incidents
        $stmt = $pdo->prepare("
            SELECT * FROM incident 
            WHERE reporter_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$userId]);
        $dashboardData['my_recent_incidents'] = $stmt->fetchAll();
    }
    
} catch (PDOException $e) {
    error_log("Dashboard data error: " . $e->getMessage());
    $dashboardData = [];
}

// Handle quick actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['quick_action'])) {
        $action = $_POST['quick_action'];
        
        switch ($action) {
            case 'mark_incident_resolved':
                if ($role === 'admin' && isset($_POST['incident_id'])) {
                    try {
                        $stmt = $pdo->prepare("UPDATE incident SET status = 'resolved', resolved_at = NOW() WHERE incident_id = ?");
                        $stmt->execute([$_POST['incident_id']]);
                        logActivity('resolve_incident', "Resolved incident ID: " . $_POST['incident_id']);
                        header('Location: dashboard.php?msg=incident_resolved');
                        exit();
                    } catch (PDOException $e) {
                        error_log("Quick action error: " . $e->getMessage());
                    }
                }
                break;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg main-header">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-traffic-light me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($firstName . ' ' . $lastName); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="nav flex-column p-3">
                <a href="dashboard.php" class="nav-link active">
                    <i class="fas fa-tachometer-alt"></i>Dashboard
                </a>
                
                <?php if ($role === 'admin'): ?>
                    <a href="vehicles.php" class="nav-link">
                        <i class="fas fa-car"></i>Vehicle Management
                    </a>
                    <a href="incident_explorer.php" class="nav-link">
                        <i class="fas fa-exclamation-triangle"></i>Incident Explorer
                    </a>
                    <a href="fines.php" class="nav-link">
                        <i class="fas fa-file-invoice-dollar"></i>Fine Ledger
                    </a>
                <?php elseif ($role === 'driver'): ?>
                    <a href="profile.php" class="nav-link">
                        <i class="fas fa-id-card"></i>My Profile
                    </a>
                    <a href="fines.php" class="nav-link">
                        <i class="fas fa-file-invoice-dollar"></i>My Fines
                    </a>
                    <a href="report_incident.php" class="nav-link">
                        <i class="fas fa-plus-circle"></i>Report Incident
                    </a>
                <?php else: // Regular user ?>
                    <a href="report_incident.php" class="nav-link">
                        <i class="fas fa-plus-circle"></i>Report Incident
                    </a>
                    <a href="incident_explorer.php" class="nav-link">
                        <i class="fas fa-list"></i>My Incidents
                    </a>
                <?php endif; ?>
                
                <!-- Common links -->
                <?php if ($role !== 'admin'): ?>
                    <a href="location.php" class="nav-link">
                        <i class="fas fa-map-marker-alt"></i>Location Tracking
                    </a>
                <?php endif; ?>
                
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>Profile
                </a>
            </div>
        </nav>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Welcome Section -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h1 class="h3 mb-0">Welcome back, <?php echo htmlspecialchars($firstName); ?>!</h1>
                            <p class="text-muted mb-0">
                                Role: <span class="badge bg-primary"><?php echo ucfirst($role); ?></span> | 
                                Last login: <?php echo date('F j, Y g:i A'); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Messages -->
            <?php if (isset($_GET['msg'])): ?>
                <?php if ($_GET['msg'] === 'incident_resolved'): ?>
                    <?php displayMessage('success', 'Incident has been marked as resolved.'); ?>
                <?php endif; ?>
            <?php endif; ?>
            
            <!-- Dashboard Statistics -->
            <?php if ($role === 'admin'): ?>
                <!-- Admin Dashboard -->
                <div class="row mb-4">
                    <div class="col-md-2 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['total_users'] ?? 0; ?></div>
                            <div class="stats-label">Total Users</div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['total_drivers'] ?? 0; ?></div>
                            <div class="stats-label">Drivers</div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['total_vehicles'] ?? 0; ?></div>
                            <div class="stats-label">Vehicles</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number text-warning"><?php echo $dashboardData['pending_incidents'] ?? 0; ?></div>
                            <div class="stats-label">Pending Incidents</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number text-danger"><?php echo $dashboardData['pending_fines'] ?? 0; ?></div>
                            <div class="stats-label">Pending Fines</div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Incidents -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Recent Incidents</h5>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($dashboardData['recent_incidents'])): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Reporter</th>
                                                    <th>Type</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($dashboardData['recent_incidents'] as $incident): ?>
                                                    <tr>
                                                        <td>#<?php echo $incident['incident_id']; ?></td>
                                                        <td><?php echo htmlspecialchars($incident['first_name'] . ' ' . $incident['last_name']); ?></td>
                                                        <td>
                                                            <span class="badge bg-info"><?php echo ucfirst(str_replace('_', ' ', $incident['incident_type'])); ?></span>
                                                        </td>
                                                        <td><?php echo date('M j, Y', strtotime($incident['incident_date'])); ?></td>
                                                        <td>
                                                            <span class="status-badge status-<?php echo $incident['status']; ?>">
                                                                <?php echo ucfirst($incident['status']); ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <?php if ($incident['status'] === 'reported'): ?>
                                                                <form method="POST" class="d-inline">
                                                                    <input type="hidden" name="quick_action" value="mark_incident_resolved">
                                                                    <input type="hidden" name="incident_id" value="<?php echo $incident['incident_id']; ?>">
                                                                    <button type="submit" class="btn btn-sm btn-success">
                                                                        <i class="fas fa-check"></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                            <a href="incident_explorer.php?id=<?php echo $incident['incident_id']; ?>" class="btn btn-sm btn-primary">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="incident_explorer.php" class="btn btn-outline-primary">
                                            View All Incidents <i class="fas fa-arrow-right ms-2"></i>
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                        <h5>No recent incidents</h5>
                                        <p class="text-muted">All incidents have been handled!</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php elseif ($role === 'driver'): ?>
                <!-- Driver Dashboard -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number text-warning"><?php echo $dashboardData['pending_fines'] ?? 0; ?></div>
                            <div class="stats-label">Pending Fines</div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['my_fines'] ?? 0; ?></div>
                            <div class="stats-label">Total Fines</div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['my_incidents'] ?? 0; ?></div>
                            <div class="stats-label">Reported Incidents</div>
                        </div>
                    </div>
                </div>
                
                <!-- Assigned Vehicle -->
                <?php if (!empty($dashboardData['assigned_vehicle'])): ?>
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-car me-2"></i>Assigned Vehicle</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p><strong>License Plate:</strong> <?php echo htmlspecialchars($dashboardData['assigned_vehicle']['license_plate']); ?></p>
                                            <p><strong>Make/Model:</strong> <?php echo htmlspecialchars($dashboardData['assigned_vehicle']['make'] . ' ' . $dashboardData['assigned_vehicle']['model']); ?></p>
                                            <p><strong>Year:</strong> <?php echo $dashboardData['assigned_vehicle']['year']; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><strong>Color:</strong> <?php echo htmlspecialchars($dashboardData['assigned_vehicle']['color']); ?></p>
                                            <p><strong>Status:</strong> 
                                                <span class="status-badge status-<?php echo $dashboardData['assigned_vehicle']['status']; ?>">
                                                    <?php echo ucfirst($dashboardData['assigned_vehicle']['status']); ?>
                                                </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Recent Fines -->
                <?php if (!empty($dashboardData['recent_fines'])): ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-file-invoice-dollar me-2"></i>Recent Fines</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Fine ID</th>
                                                    <th>Violation</th>
                                                    <th>Amount</th>
                                                    <th>Issue Date</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($dashboardData['recent_fines'] as $fine): ?>
                                                    <tr>
                                                        <td>#<?php echo $fine['fine_id']; ?></td>
                                                        <td><?php echo htmlspecialchars($fine['violation_type']); ?></td>
                                                        <td>$<?php echo number_format($fine['fine_amount'], 2); ?></td>
                                                        <td><?php echo date('M j, Y', strtotime($fine['issue_date'])); ?></td>
                                                        <td>
                                                            <span class="status-badge status-<?php echo $fine['status']; ?>">
                                                                <?php echo ucfirst($fine['status']); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="fines.php" class="btn btn-outline-primary">
                                            View All Fines <i class="fas fa-arrow-right ms-2"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <!-- User Dashboard -->
                <div class="row mb-4">
                    <div class="col-md-6 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['my_incidents'] ?? 0; ?></div>
                            <div class="stats-label">Reported Incidents</div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="stats-card text-center">
                            <div class="stats-number"><?php echo $dashboardData['my_locations'] ?? 0; ?></div>
                            <div class="stats-label">Location Records</div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <a href="report_incident.php" class="btn btn-primary w-100 p-3">
                                            <i class="fas fa-plus-circle fa-2x mb-2"></i><br>
                                            Report New Incident
                                        </a>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <a href="location.php" class="btn btn-outline-primary w-100 p-3">
                                            <i class="fas fa-map-marker-alt fa-2x mb-2"></i><br>
                                            Track Location
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Incidents -->
                <?php if (!empty($dashboardData['my_recent_incidents'])): ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>My Recent Incidents</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Type</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($dashboardData['my_recent_incidents'] as $incident): ?>
                                                    <tr>
                                                        <td>#<?php echo $incident['incident_id']; ?></td>
                                                        <td>
                                                            <span class="badge bg-info"><?php echo ucfirst(str_replace('_', ' ', $incident['incident_type'])); ?></span>
                                                        </td>
                                                        <td><?php echo date('M j, Y', strtotime($incident['incident_date'])); ?></td>
                                                        <td>
                                                            <span class="status-badge status-<?php echo $incident['status']; ?>">
                                                                <?php echo ucfirst($incident['status']); ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a href="incident_explorer.php?id=<?php echo $incident['incident_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                                <i class="fas fa-eye"></i> View
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>