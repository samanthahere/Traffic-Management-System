<?php
/**
 * Traffic Management System - Report Incident
 * User form to report traffic incidents
 */

// Include configuration file
require_once 'config.php';

// Require user to be logged in
requireLogin();

// Get user information
$userId = getSessionData('user_id');
$role = getSessionData('role');

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['report_incident'])) {
    $incidentType = sanitizeInput($_POST['incident_type']);
    $description = sanitizeInput($_POST['description']);
    $incidentDate = sanitizeInput($_POST['incident_date']);
    $locationAddress = sanitizeInput($_POST['location_address']);
    $latitude = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
    $longitude = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;
    $vehiclesInvolved = sanitizeInput($_POST['vehicles_involved']);
    $driversInvolved = sanitizeInput($_POST['drivers_involved']);
    $severity = sanitizeInput($_POST['severity']);
    
    // Validation
    if (empty($incidentType)) $errors[] = 'Incident type is required.';
    if (empty($description)) $errors[] = 'Description is required.';
    if (empty($incidentDate)) $errors[] = 'Incident date and time is required.';
    if (empty($locationAddress)) $errors[] = 'Location address is required.';
    if (empty($severity)) $errors[] = 'Severity level is required.';
    
    // Validate incident date (not in the future)
    if (!empty($incidentDate) && strtotime($incidentDate) > time()) {
        $errors[] = 'Incident date cannot be in the future.';
    }
    
    // Validate incident date (not more than 30 days old)
    if (!empty($incidentDate) && strtotime($incidentDate) < strtotime('-30 days')) {
        $errors[] = 'Incident date cannot be more than 30 days old.';
    }
    
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            
            // Prepare vehicles and drivers as JSON if provided
            $vehiclesJson = null;
            $driversJson = null;
            
            if (!empty($vehiclesInvolved)) {
                $vehiclesList = array_filter(array_map('trim', explode(',', $vehiclesInvolved)));
                $vehiclesJson = json_encode($vehiclesList);
            }
            
            if (!empty($driversInvolved)) {
                $driversList = array_filter(array_map('trim', explode(',', $driversInvolved)));
                $driversJson = json_encode($driversList);
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO incident (reporter_id, incident_type, description, incident_date, 
                                    location_address, latitude, longitude, vehicles_involved, 
                                    drivers_involved, severity) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $userId, $incidentType, $description, $incidentDate,
                $locationAddress, $latitude, $longitude, $vehiclesJson,
                $driversJson, $severity
            ]);
            
            $incidentId = $pdo->lastInsertId();
            $success = true;
            
            logActivity('report_incident', "Reported incident ID: $incidentId");
            
        } catch (PDOException $e) {
            $errors[] = 'Failed to submit incident report. Please try again.';
            error_log("Incident report error: " . $e->getMessage());
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Incident - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg main-header">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-traffic-light me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <div class="navbar-nav ms-auto">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">
                            <i class="fas fa-exclamation-triangle me-2"></i>Report Traffic Incident
                        </h4>
                        <p class="mb-0 text-muted">Please provide detailed information about the incident</p>
                    </div>
                    
                    <div class="card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success text-center">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <h5>Incident Report Submitted Successfully!</h5>
                                <p class="mb-3">Your incident report has been received and will be reviewed by our team.</p>
                                <div class="d-flex gap-2 justify-content-center">
                                    <a href="report_incident.php" class="btn btn-outline-primary">
                                        <i class="fas fa-plus me-2"></i>Report Another Incident
                                    </a>
                                    <a href="dashboard.php" class="btn btn-primary">
                                        <i class="fas fa-home me-2"></i>Back to Dashboard
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <?php if (!empty($errors)): ?>
                                <div class="alert alert-danger">
                                    <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                                    <ul class="mb-0">
                                        <?php foreach ($errors as $error): ?>
                                            <li><?php echo htmlspecialchars($error); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="" id="incidentForm">
                                <!-- Basic Incident Information -->
                                <h6 class="mb-3"><i class="fas fa-info-circle me-2"></i>Incident Details</h6>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="incident_type" class="form-label">Incident Type *</label>
                                        <select class="form-select" id="incident_type" name="incident_type" required>
                                            <option value="">Select incident type</option>
                                            <option value="accident" <?php echo (isset($incidentType) && $incidentType === 'accident') ? 'selected' : ''; ?>>
                                                Traffic Accident
                                            </option>
                                            <option value="traffic_violation" <?php echo (isset($incidentType) && $incidentType === 'traffic_violation') ? 'selected' : ''; ?>>
                                                Traffic Violation
                                            </option>
                                            <option value="emergency" <?php echo (isset($incidentType) && $incidentType === 'emergency') ? 'selected' : ''; ?>>
                                                Emergency Situation
                                            </option>
                                            <option value="other" <?php echo (isset($incidentType) && $incidentType === 'other') ? 'selected' : ''; ?>>
                                                Other
                                            </option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="severity" class="form-label">Severity Level *</label>
                                        <select class="form-select" id="severity" name="severity" required>
                                            <option value="">Select severity</option>
                                            <option value="low" <?php echo (isset($severity) && $severity === 'low') ? 'selected' : ''; ?>>
                                                Low - Minor issue
                                            </option>
                                            <option value="medium" <?php echo (isset($severity) && $severity === 'medium') ? 'selected' : ''; ?>>
                                                Medium - Moderate concern
                                            </option>
                                            <option value="high" <?php echo (isset($severity) && $severity === 'high') ? 'selected' : ''; ?>>
                                                High - Serious issue
                                            </option>
                                            <option value="critical" <?php echo (isset($severity) && $severity === 'critical') ? 'selected' : ''; ?>>
                                                Critical - Emergency
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="incident_date" class="form-label">Incident Date & Time *</label>
                                    <input type="datetime-local" class="form-control" id="incident_date" name="incident_date" 
                                           value="<?php echo isset($incidentDate) ? $incidentDate : ''; ?>" required>
                                    <div class="form-text">When did this incident occur?</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description *</label>
                                    <textarea class="form-control" id="description" name="description" rows="4" 
                                              placeholder="Please provide a detailed description of what happened..." required><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                                    <div class="form-text">Be as detailed as possible. Include what you saw, heard, or experienced.</div>
                                </div>
                                
                                <!-- Location Information -->
                                <h6 class="mb-3 mt-4"><i class="fas fa-map-marker-alt me-2"></i>Location Information</h6>
                                
                                <div class="mb-3">
                                    <label for="location_address" class="form-label">Location Address *</label>
                                    <input type="text" class="form-control" id="location_address" name="location_address" 
                                           value="<?php echo isset($locationAddress) ? htmlspecialchars($locationAddress) : ''; ?>"
                                           placeholder="Street address, intersection, or landmark" required>
                                    <div class="form-text">Where exactly did this incident take place?</div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="latitude" class="form-label">Latitude (Optional)</label>
                                        <input type="number" class="form-control" id="latitude" name="latitude" 
                                               value="<?php echo isset($latitude) ? $latitude : ''; ?>"
                                               step="0.0000001" placeholder="e.g., 40.7128">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="longitude" class="form-label">Longitude (Optional)</label>
                                        <input type="number" class="form-control" id="longitude" name="longitude" 
                                               value="<?php echo isset($longitude) ? $longitude : ''; ?>"
                                               step="0.0000001" placeholder="e.g., -74.0060">
                                    </div>
                                </div>
                                
                                <div class="text-center mb-3">
                                    <button type="button" class="btn btn-outline-info" id="getLocationBtn">
                                        <i class="fas fa-crosshairs me-2"></i>Get My Current Location
                                    </button>
                                </div>
                                
                                <!-- Involved Parties -->
                                <h6 class="mb-3 mt-4"><i class="fas fa-users me-2"></i>Involved Parties (Optional)</h6>
                                
                                <div class="mb-3">
                                    <label for="vehicles_involved" class="form-label">Vehicles Involved</label>
                                    <input type="text" class="form-control" id="vehicles_involved" name="vehicles_involved" 
                                           value="<?php echo isset($vehiclesInvolved) ? htmlspecialchars($vehiclesInvolved) : ''; ?>"
                                           placeholder="License plates separated by commas (e.g., ABC123, XYZ789)">
                                    <div class="form-text">Enter license plate numbers if known</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="drivers_involved" class="form-label">Drivers/People Involved</label>
                                    <input type="text" class="form-control" id="drivers_involved" name="drivers_involved" 
                                           value="<?php echo isset($driversInvolved) ? htmlspecialchars($driversInvolved) : ''; ?>"
                                           placeholder="Names or descriptions separated by commas">
                                    <div class="form-text">Enter names or descriptions if known (e.g., "John Doe", "Driver of red car")</div>
                                </div>
                                
                                <!-- Guidelines -->
                                <div class="alert alert-info mt-4">
                                    <h6><i class="fas fa-info-circle me-2"></i>Reporting Guidelines:</h6>
                                    <ul class="mb-0">
                                        <li>Be honest and factual in your report</li>
                                        <li>Include as much detail as possible</li>
                                        <li>For emergencies, call 911 first before reporting here</li>
                                        <li>Your report will be reviewed by our traffic management team</li>
                                        <li>You may be contacted for additional information</li>
                                    </ul>
                                </div>
                                
                                <div class="row mt-4">
                                    <div class="col-6">
                                        <a href="dashboard.php" class="btn btn-outline-secondary w-100">
                                            <i class="fas fa-times me-2"></i>Cancel
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <button type="submit" name="report_incident" class="btn btn-primary w-100">
                                            <i class="fas fa-paper-plane me-2"></i>Submit Report
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Set current time as default for incident date
    document.addEventListener('DOMContentLoaded', function() {
        const now = new Date();
        const currentDateTime = now.toISOString().slice(0, 16);
        if (!document.getElementById('incident_date').value) {
            document.getElementById('incident_date').value = currentDateTime;
        }
        
        // Get current location
        document.getElementById('getLocationBtn').addEventListener('click', function() {
            const btn = this;
            const originalText = btn.innerHTML;
            
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Getting Location...';
            btn.disabled = true;
            
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        document.getElementById('latitude').value = position.coords.latitude.toFixed(7);
                        document.getElementById('longitude').value = position.coords.longitude.toFixed(7);
                        
                        btn.innerHTML = '<i class="fas fa-check me-2"></i>Location Retrieved!';
                        btn.className = 'btn btn-success';
                        
                        setTimeout(function() {
                            btn.innerHTML = originalText;
                            btn.className = 'btn btn-outline-info';
                            btn.disabled = false;
                        }, 2000);
                    },
                    function(error) {
                        btn.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Location Failed';
                        btn.className = 'btn btn-warning';
                        
                        setTimeout(function() {
                            btn.innerHTML = originalText;
                            btn.className = 'btn btn-outline-info';
                            btn.disabled = false;
                        }, 2000);
                        
                        console.error('Geolocation error:', error);
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 60000
                    }
                );
            } else {
                alert('Geolocation is not supported by this browser.');
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        });
        
        // Form validation
        document.getElementById('incidentForm').addEventListener('submit', function(e) {
            const incidentDate = new Date(document.getElementById('incident_date').value);
            const now = new Date();
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
            
            if (incidentDate > now) {
                e.preventDefault();
                alert('Incident date cannot be in the future.');
                return false;
            }
            
            if (incidentDate < thirtyDaysAgo) {
                e.preventDefault();
                alert('Incident date cannot be more than 30 days old.');
                return false;
            }
        });
    });
    </script>
</body>
</html>