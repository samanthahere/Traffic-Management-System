<?php
/**
 * Traffic Management System - Registration Page
 * User and Driver registration with role selection
 */

// Include configuration file
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$errors = [];
$success = false;

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    // Sanitize and validate input
    $firstName = sanitizeInput($_POST['first_name']);
    $lastName = sanitizeInput($_POST['last_name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);
    $dateOfBirth = sanitizeInput($_POST['date_of_birth']);
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $role = sanitizeInput($_POST['role']);
    
    // Driver-specific fields
    $ssn = isset($_POST['ssn']) ? sanitizeInput($_POST['ssn']) : '';
    $licenseNumber = isset($_POST['license_number']) ? sanitizeInput($_POST['license_number']) : '';
    $licenseExpiry = isset($_POST['license_expiry']) ? sanitizeInput($_POST['license_expiry']) : '';
    $licenseClass = isset($_POST['license_class']) ? sanitizeInput($_POST['license_class']) : '';
    $experienceYears = isset($_POST['experience_years']) ? (int)$_POST['experience_years'] : 0;
    
    // Validation
    if (empty($firstName)) $errors[] = 'First name is required.';
    if (empty($lastName)) $errors[] = 'Last name is required.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (empty($username) || strlen($username) < 3) $errors[] = 'Username must be at least 3 characters long.';
    if (empty($password) || strlen($password) < 6) $errors[] = 'Password must be at least 6 characters long.';
    if ($password !== $confirmPassword) $errors[] = 'Passwords do not match.';
    if (!in_array($role, ['user', 'driver'])) $errors[] = 'Invalid role selected.';
    
    // Driver-specific validation
    if ($role === 'driver') {
        if (empty($ssn)) $errors[] = 'SSN is required for drivers.';
        if (empty($licenseNumber)) $errors[] = 'License number is required for drivers.';
        if (empty($licenseExpiry)) $errors[] = 'License expiry date is required for drivers.';
        if (empty($licenseClass)) $errors[] = 'License class is required for drivers.';
        if ($experienceYears < 0) $errors[] = 'Experience years cannot be negative.';
        
        // Validate license expiry date
        if (!empty($licenseExpiry) && strtotime($licenseExpiry) <= time()) {
            $errors[] = 'License expiry date must be in the future.';
        }
    }
    
    // Check if username or email already exists
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            
            // Check username
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM user WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Username already exists.';
            }
            
            // Check email
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM person WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Email already exists.';
            }
            
            // Check SSN for drivers
            if ($role === 'driver' && !empty($ssn)) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM driver WHERE ssn = ?");
                $stmt->execute([$ssn]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = 'SSN already exists in driver records.';
                }
                
                // Check license number
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM driver WHERE license_number = ?");
                $stmt->execute([$licenseNumber]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = 'License number already exists.';
                }
            }
            
        } catch (PDOException $e) {
            $errors[] = 'Database error. Please try again later.';
            error_log("Registration validation error: " . $e->getMessage());
        }
    }
    
    // If no errors, create the user
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            $pdo->beginTransaction();
            
            // Insert into person table
            $stmt = $pdo->prepare("
                INSERT INTO person (first_name, last_name, email, phone, address, date_of_birth) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$firstName, $lastName, $email, $phone, $address, $dateOfBirth]);
            $personId = $pdo->lastInsertId();
            
            // Hash password
            $passwordHash = password_hash($password, PASSWORD_HASH_ALGO);
            
            // Insert into user table
            $stmt = $pdo->prepare("
                INSERT INTO user (user_id, username, password_hash, role) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$personId, $username, $passwordHash, $role]);
            
            // If driver, insert into driver table
            if ($role === 'driver') {
                $stmt = $pdo->prepare("
                    INSERT INTO driver (driver_id, ssn, license_number, license_expiry, license_class, experience_years) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$personId, $ssn, $licenseNumber, $licenseExpiry, $licenseClass, $experienceYears]);
            }
            
            $pdo->commit();
            $success = true;
            
            // Log successful registration
            error_log("New user registered: $username ($role)");
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = 'Registration failed. Please try again.';
            error_log("Registration error: " . $e->getMessage());
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?php echo SITE_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow">
                    <div class="card-header text-center">
                        <h3><i class="fas fa-user-plus me-2"></i>User Registration</h3>
                        <p class="mb-0 text-muted">Create your account to access the Traffic Management System</p>
                    </div>
                    
                    <div class="card-body p-4">
                        <?php if ($success): ?>
                            <div class="alert alert-success text-center">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <h5>Registration Successful!</h5>
                                <p class="mb-3">Your account has been created successfully.</p>
                                <a href="index.php?registered=1" class="btn btn-primary">
                                    <i class="fas fa-sign-in-alt me-2"></i>Login Now
                                </a>
                            </div>
                        <?php else: ?>
                            <?php if (!empty($errors)): ?>
                                <div class="alert alert-danger">
                                    <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                                    <ul class="mb-0">
                                        <?php foreach ($errors as $error): ?>
                                            <li><?php echo htmlspecialchars($error); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="" id="registrationForm">
                                <!-- Role Selection -->
                                <div class="mb-4">
                                    <label class="form-label"><i class="fas fa-user-tag me-2"></i>Account Type</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="role" id="role_user" 
                                                       value="user" <?php echo (!isset($role) || $role === 'user') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="role_user">
                                                    <i class="fas fa-user me-2"></i>Regular User
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="role" id="role_driver" 
                                                       value="driver" <?php echo (isset($role) && $role === 'driver') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="role_driver">
                                                    <i class="fas fa-car me-2"></i>Driver
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Personal Information -->
                                <h6 class="mb-3"><i class="fas fa-user me-2"></i>Personal Information</h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="first_name" class="form-label">First Name *</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" 
                                               value="<?php echo isset($firstName) ? htmlspecialchars($firstName) : ''; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="last_name" class="form-label">Last Name *</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" 
                                               value="<?php echo isset($lastName) ? htmlspecialchars($lastName) : ''; ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>"
                                               placeholder="(123) 456-7890">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="date_of_birth" class="form-label">Date of Birth</label>
                                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 
                                               value="<?php echo isset($dateOfBirth) ? htmlspecialchars($dateOfBirth) : ''; ?>">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <textarea class="form-control" id="address" name="address" rows="2" 
                                              placeholder="Street address, City, State, ZIP"><?php echo isset($address) ? htmlspecialchars($address) : ''; ?></textarea>
                                </div>
                                
                                <!-- Account Information -->
                                <h6 class="mb-3 mt-4"><i class="fas fa-key me-2"></i>Account Information</h6>
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username *</label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" 
                                           required minlength="3">
                                    <div class="form-text">At least 3 characters, letters and numbers only</div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="password" class="form-label">Password *</label>
                                        <input type="password" class="form-control" id="password" name="password" 
                                               required minlength="6">
                                        <div class="form-text">Minimum 6 characters</div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="confirm_password" class="form-label">Confirm Password *</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                               required minlength="6">
                                    </div>
                                </div>
                                
                                <!-- Driver-specific fields -->
                                <div id="driver_fields" style="display: none;">
                                    <h6 class="mb-3 mt-4"><i class="fas fa-id-card me-2"></i>Driver Information</h6>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="ssn" class="form-label">SSN *</label>
                                            <input type="text" class="form-control" id="ssn" name="ssn" 
                                                   value="<?php echo isset($ssn) ? htmlspecialchars($ssn) : ''; ?>"
                                                   placeholder="123-45-6789">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="license_number" class="form-label">License Number *</label>
                                            <input type="text" class="form-control" id="license_number" name="license_number" 
                                                   value="<?php echo isset($licenseNumber) ? htmlspecialchars($licenseNumber) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="license_expiry" class="form-label">License Expiry *</label>
                                            <input type="date" class="form-control" id="license_expiry" name="license_expiry" 
                                                   value="<?php echo isset($licenseExpiry) ? htmlspecialchars($licenseExpiry) : ''; ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="license_class" class="form-label">License Class *</label>
                                            <select class="form-select" id="license_class" name="license_class">
                                                <option value="">Select Class</option>
                                                <option value="Class A" <?php echo (isset($licenseClass) && $licenseClass === 'Class A') ? 'selected' : ''; ?>>Class A</option>
                                                <option value="Class B" <?php echo (isset($licenseClass) && $licenseClass === 'Class B') ? 'selected' : ''; ?>>Class B</option>
                                                <option value="Class C" <?php echo (isset($licenseClass) && $licenseClass === 'Class C') ? 'selected' : ''; ?>>Class C</option>
                                                <option value="CDL" <?php echo (isset($licenseClass) && $licenseClass === 'CDL') ? 'selected' : ''; ?>>CDL</option>
                                                <option value="Motorcycle" <?php echo (isset($licenseClass) && $licenseClass === 'Motorcycle') ? 'selected' : ''; ?>>Motorcycle</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="experience_years" class="form-label">Experience (Years)</label>
                                            <input type="number" class="form-control" id="experience_years" name="experience_years" 
                                                   value="<?php echo isset($experienceYears) ? $experienceYears : '0'; ?>" 
                                                   min="0" max="50">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row mt-4">
                                    <div class="col-6">
                                        <a href="index.php" class="btn btn-outline-secondary w-100">
                                            <i class="fas fa-arrow-left me-2"></i>Back to Login
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <button type="submit" name="register" class="btn btn-primary w-100">
                                            <i class="fas fa-user-plus me-2"></i>Register
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Show/hide driver fields based on role selection
    function toggleDriverFields() {
        const driverRadio = document.getElementById('role_driver');
        const driverFields = document.getElementById('driver_fields');
        const driverInputs = driverFields.querySelectorAll('input, select');
        
        if (driverRadio.checked) {
            driverFields.style.display = 'block';
            // Make driver fields required
            document.getElementById('ssn').required = true;
            document.getElementById('license_number').required = true;
            document.getElementById('license_expiry').required = true;
            document.getElementById('license_class').required = true;
        } else {
            driverFields.style.display = 'none';
            // Remove required attribute from driver fields
            driverInputs.forEach(input => {
                input.required = false;
            });
        }
    }
    
    // Event listeners for role change
    document.getElementById('role_user').addEventListener('change', toggleDriverFields);
    document.getElementById('role_driver').addEventListener('change', toggleDriverFields);
    
    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        toggleDriverFields();
        
        // Password confirmation validation
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        
        function validatePassword() {
            if (password.value !== confirmPassword.value) {
                confirmPassword.setCustomValidity('Passwords do not match');
            } else {
                confirmPassword.setCustomValidity('');
            }
        }
        
        password.addEventListener('input', validatePassword);
        confirmPassword.addEventListener('input', validatePassword);
        
        // Phone number formatting
        const phoneInput = document.getElementById('phone');
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 6) {
                value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
            } else if (value.length >= 3) {
                value = value.replace(/(\d{3})(\d{3})/, '($1) $2');
            }
            e.target.value = value;
        });
        
        // SSN formatting
        const ssnInput = document.getElementById('ssn');
        ssnInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 5) {
                value = value.replace(/(\d{3})(\d{2})(\d{4})/, '$1-$2-$3');
            } else if (value.length >= 3) {
                value = value.replace(/(\d{3})(\d{2})/, '$1-$2');
            }
            e.target.value = value;
        });
    });
    </script>
</body>
</html>