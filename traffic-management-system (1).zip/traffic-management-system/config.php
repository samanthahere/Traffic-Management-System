<?php
/**
 * Database Configuration File
 * Traffic Management System
 * 
 * This file contains database connection settings and helper functions
 * for connecting to MySQL database securely.
 */

// Start session for user authentication
session_start();

// Database configuration constants
define('DB_HOST', 'localhost');
define('DB_NAME', 'traffic_management');
define('DB_USER', 'root');  // Change this to your MySQL username
define('DB_PASS', '');      // Change this to your MySQL password
define('DB_CHARSET', 'utf8mb4');

// Site configuration
define('SITE_NAME', 'Traffic Management System');
define('SITE_URL', 'http://localhost/traffic-management-system');

// Security settings
define('PASSWORD_HASH_ALGO', PASSWORD_DEFAULT);
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

/**
 * Get database connection using PDO
 * Returns a PDO connection object with error handling
 */
function getDBConnection() {
    try {
        // Create PDO connection string
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        
        // PDO options for better security and error handling
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        // Create and return PDO connection
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
        
    } catch (PDOException $e) {
        // Log error and show user-friendly message
        error_log("Database connection failed: " . $e->getMessage());
        die("Database connection failed. Please contact system administrator.");
    }
}

/**
 * Check if user is logged in
 * Returns boolean true if user is authenticated
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

/**
 * Check if user has specific role
 * @param string $role - Role to check (admin, driver, user)
 * @return boolean
 */
function hasRole($role) {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

/**
 * Check if user is admin
 * @return boolean
 */
function isAdmin() {
    return hasRole('admin');
}

/**
 * Check if user is driver
 * @return boolean
 */
function isDriver() {
    return hasRole('driver');
}

/**
 * Redirect user to login page if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php?error=login_required');
        exit();
    }
}

/**
 * Redirect user if they don't have required role
 * @param string $required_role - Required role
 */
function requireRole($required_role) {
    requireLogin();
    if (!hasRole($required_role)) {
        header('Location: dashboard.php?error=access_denied');
        exit();
    }
}

/**
 * Sanitize input data
 * @param string $data - Input data to sanitize
 * @return string - Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Generate CSRF token for forms
 * @return string - CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * @param string $token - Token to verify
 * @return boolean
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Display success or error messages
 * @param string $type - Message type (success, error, warning, info)
 * @param string $message - Message text
 */
function displayMessage($type, $message) {
    $alertClass = '';
    switch($type) {
        case 'success':
            $alertClass = 'alert-success';
            break;
        case 'error':
            $alertClass = 'alert-danger';
            break;
        case 'warning':
            $alertClass = 'alert-warning';
            break;
        case 'info':
            $alertClass = 'alert-info';
            break;
        default:
            $alertClass = 'alert-info';
    }
    
    echo "<div class='alert {$alertClass} alert-dismissible fade show' role='alert'>";
    echo htmlspecialchars($message);
    echo "<button type='button' class='btn-close' data-bs-dismiss='alert'></button>";
    echo "</div>";
}

/**
 * Get user information from session
 * @param string $key - Session key to retrieve
 * @return mixed - Session value or null
 */
function getSessionData($key) {
    return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
}

/**
 * Log user activity for audit trail
 * @param string $action - Action performed
 * @param string $details - Additional details
 */
function logActivity($action, $details = '') {
    if (isLoggedIn()) {
        try {
            $pdo = getDBConnection();
            // Note: You might want to create an activity_log table for this
            error_log("User Activity - ID: " . $_SESSION['user_id'] . ", Action: $action, Details: $details");
        } catch (Exception $e) {
            error_log("Failed to log activity: " . $e->getMessage());
        }
    }
}

/**
 * Check session timeout
 */
function checkSessionTimeout() {
    if (isLoggedIn()) {
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            // Session expired
            session_destroy();
            header('Location: index.php?error=session_expired');
            exit();
        }
        $_SESSION['last_activity'] = time();
    }
}

// Check session timeout on every page load
checkSessionTimeout();

// Set timezone
date_default_timezone_set('America/New_York'); // Change to your timezone

?>
